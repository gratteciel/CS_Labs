﻿using System;
class Prof
{
    public void Report(double average)
    {
        Console.WriteLine("My name is Prof, I received the new average of Student named {0} successfully.", average);
    }
}