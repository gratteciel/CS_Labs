﻿using System;
class Registrar
{
    public void Report(double average)
    {
        Console.WriteLine("My name is Registrar, I received the new average of Student named {0} successfully.", average);
    }
}