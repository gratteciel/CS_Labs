﻿class Student
{
    public string FullName { get; set; }
    public double AverageGrade { get; set; }
    public int NumberOfCourses { get; set; }

    public delegate void AvgChanged(double average);
    public event AvgChanged OnAvgChanged;

    public Student(string fullName, double averageGrade, int numberOfCourses)
    {
        FullName = fullName;
        AverageGrade = averageGrade;
        NumberOfCourses = numberOfCourses;
    }

    public void RecordGrade(double newGrade)
    {
        AverageGrade = (AverageGrade * NumberOfCourses + newGrade) / (NumberOfCourses + 1);
        OnAvgChanged?.Invoke(AverageGrade);
    }
}